package cat.itb.m9.springboot.exercicis.ex05formularis_lombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex05formularisLombokApplicationTests {

    @Test
    void contextLoads() {
    }

}
