package cat.itb.m9.springboot.exercicis.ex05formularis_lombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex05formularisLombokApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ex05formularisLombokApplication.class, args);
    }

}
