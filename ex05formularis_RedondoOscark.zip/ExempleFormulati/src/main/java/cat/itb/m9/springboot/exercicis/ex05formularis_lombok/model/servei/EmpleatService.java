package cat.itb.m9.springboot.exercicis.ex05formularis_lombok.model.servei;

import cat.itb.m9.springboot.exercicis.ex05formularis_lombok.model.entitat.Empleat;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.*;

@Service
public class EmpleatService {
    private List<Empleat> repositori = new ArrayList<>();
    public void afegir(Empleat e) {
        repositori.add(e);
    }
    public List<Empleat> llistat() {
        return repositori;
    }
    public List<Empleat> llistatOrdenatPerNom(){
        Collections.sort(repositori, new Comparator<Empleat>() {
            @Override
            public int compare(Empleat e1, Empleat e2) {
                return e1.getNom().compareToIgnoreCase(e2.getNom());
            }
        });
        return repositori;

    }
    public Empleat consultaPerId(int id){
        for (Empleat e:repositori) {
            if (e.getId()==id) return e;
        }
        return null;
    }
    public void eliminarPerId(int  id){
        repositori.removeIf(e -> e.getId() == id);
    }
    public void subsistuir(Empleat e){
        repositori.add(e);
    }

    @PostConstruct
    public void init() {
        repositori.addAll(
                Arrays.asList(
                        new Empleat(1, "Montse Madridejos", "montse@itb.cat", "677123456",true),
                        new Empleat(2, "Alberto Vila", "alberto@itb.cat", "699876543",true),
                        new Empleat(3, "Robert López", "robert@bbc.com", "123456789",false)
                )
        );
    }
}
