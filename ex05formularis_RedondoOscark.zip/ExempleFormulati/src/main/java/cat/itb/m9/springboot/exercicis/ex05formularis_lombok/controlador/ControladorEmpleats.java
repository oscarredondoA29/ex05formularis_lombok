package cat.itb.m9.springboot.exercicis.ex05formularis_lombok.controlador;


import cat.itb.m9.springboot.exercicis.ex05formularis_lombok.model.entitat.Empleat;
import cat.itb.m9.springboot.exercicis.ex05formularis_lombok.model.servei.EmpleatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControladorEmpleats {
    @Autowired
    private EmpleatService servei;

    @GetMapping("/empleats/list")
    public String llistar(Model m){
        m.addAttribute("llistaEmpleats",servei.llistat());
        return "llistat";
    }

    //ordenats per no3
    @GetMapping("/empleats/listOrdenat")
    public String llistarOrdenat(Model m){
        m.addAttribute("llistaEmpleats",servei.llistatOrdenatPerNom());
        return "llistatOrdenatPerNom";
    }



    @GetMapping("/eliminar")
    public String eliminar(@RequestParam("id") int id){
        servei.eliminarPerId(id);

        return "redirect:/empleats/list";
    }



    /* inici de l'aplicació. Anem a afegir Empleats amb un formulari*/
    @GetMapping("/empleats/new")
    public String afegirEmpleat(Model m){
        //cal instanciar l'empleat, pq sino el CommandObject no existeix al formulari
       m.addAttribute("empleatForm",new Empleat());
        return "afegir";
    }


    //ex4
    @PostMapping("empleats/new/submit")
    //empleatForm és el nom de l'objecte que es recull al formulari, el CommandObject (bean)
    //https://www.thymeleaf.org/doc/tutorials/2.1/thymeleafspring.html#handling-the-command-object
    public String afegirSubmit(@ModelAttribute("empleatForm") Empleat emp){

        if (emp.getId()==0){
            emp.setId(servei.llistat().size()+1);
            servei.afegir(emp);
        }else {
            servei.eliminarPerId(emp.getId());
            servei.subsistuir(emp);
        }

      return "redirect:/empleats/list";
    }
}
